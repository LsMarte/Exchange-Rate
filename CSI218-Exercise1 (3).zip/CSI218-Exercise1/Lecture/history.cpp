/*
 * Name: Luis Marte
 * History Member Function Definitions
 * Course: CSI 218 (Spring 2025)
 * Lecture: Tools for Data Structures
 * Date: January 27, 2025
 * Description: History member function definitions.
 */

#ifndef HISTORY_CPP
#define HISTORY_CPP

#include <iostream>
#include "history.h"
using namespace std;

// History member function definitions.

// Constructors

template<class T>
History<T>::History()  // History<T> is PARAMETERIZED TYPE QUALIFIER
{
    clear();
}

// Accessors

template<class T>  // TEMPLATE PREFIX
T History<T>::get(int i) const
{
	if (i >= 0 && i < MAX_HISTORY)
		return stored[i];
	else
	{
		cerr << "Invalid history index: " << i << endl;
		return T();
	}
}

template<class T>
void History<T>::output() const
{
	cout << "History:";

	for (int i = 0; i < MAX_HISTORY; i++)
		if (stored[i] != T())
			cout << " " << stored[i];
}

template<class T>
double History<T>::size() const
{
	int count = 0;
	for (int i = 0; i < MAX_HISTORY; i++)
		if (store[i] != T())
			count++;
	return count;
}

// Mutators

template<class T>
void History<T>::add(const T& val)
{
	for (int i = 0; i < MAX_HISTORY; i++)
		if (stored[i] == T())
		{
			stored[i] = val;
			break;
		}
}

// Clear price history (default value entries signals unused entries).
template<class T>
void History<T>::clear()
{
	for (int i = 0; i < MAX_HISTORY; i++)
		stored[i] = T();  // T() IS ANONYMOUS OBJECT OF TYPE "T"
}

#endif
