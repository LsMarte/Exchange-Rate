/*
 * Name: Luis Marte
 * Product Class Definition
 * Course: CSI 218 (Spring 2025)
 * Lecture: Tools for Data Structures
 * Date: January 27, 2025
 * Description: Product class definition declaring
 *				data members and member functions.
 */

#ifndef PRODUCT_H
#define PRODUCT_H

#include <string>
#include "history.h"
#include "history.cpp"




// See https://stackoverflow.com/questions/5849457/using-namespace-in-c-headers
using namespace std;

namespace Store
{
	// Product class definition with data members and
	// prototypes for member functions.

	class Product
	{
	public:
		// Constructors
		Product();  // default constructor (no parameters)
		Product(const string& newId,
				double newPrice,
				bool newTaxable);

		// Accessors
		string getId() const;
		double getPrice() const;
		double getAlternatePrice()const;
		double getExchangeRate()const;
		double getAverageExchangeRate()const;
		// A new acessor for average exchange rate.

		void output() const;

		double computeTax(double taxRate) const;
		// Precondition: taxRate must be non-negative and represented
		// as a decimal (e.g., 0.05 for 5%).
		// Postcondition: Returns amount of tax based on price of
		// product and given taxRate.

		// Mutators
		void set(const string& newId,
				 double newPrice,
				 bool newTaxable);
		// Precondition: newPrice must be a non-negative number.

		// Set only price.
		void setPrice(double newPrice);
		// Precondition: newPrice must be a non-negative number.
		 
		// Set exchange rate to the alternate currency.
		void setExchangeRate(double newExchangeRate);
		// Precondition: newExchangeRate must be a non-negative number.

	private:
		string id;
		double price;
		bool taxable;
		double exchangeRate; // Exchange rate for alternate currency.
		History<double> priceHistory;
		History<double> alternatePriceHistory;// History of prices in alternate currency.
	};
}

#endif