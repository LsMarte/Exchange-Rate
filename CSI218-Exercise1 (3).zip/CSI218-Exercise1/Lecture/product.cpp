/*
 * Name: YOUR Luis Marte
 * Product Member Function Definitions
 * Course: CSI 218 (Spring 2025)
 * Lecture: Tools for Data Structures
 * Date: January 27, 2025
 * Description: Product member function definitions.
 */


#include <iostream>
#include <iomanip>  // for setprecision()
#include "product.h"

using namespace std;

namespace Store
{
	// Product member function definitions.

	// Constructors

	Product::Product()  // default constructor

	{
		id = "00-000-00";
		price = 0.00;
		exchangeRate = 1.0;
		taxable = false;
	}

	Product::Product(const string& newId,
		double newPrice,
		bool newTaxable)
	{
		// Call member function "set" to initialize
		// data members.  Price will be checked for
		// validity.
		set(newId, newPrice, newTaxable);

	}

	// Accessors

	string Product::getId() const
	{
		return id;
	}

	double Product::getPrice() const
	{
		return price;
	}

	double Product::getAlternatePrice() const
	{
		return price / exchangeRate;
	}

	double Product::getExchangeRate() const
	{
		return exchangeRate;
	}

	void Product::output() const
	{
		cout << "Id: " << id << endl
			<< "Price: $"
			<< fixed << setprecision(2)
			<< price;

		cout << " (";
		priceHistory.output();
		cout << ")" << endl;

		cout << "Alternate Currency Price: $"
			<< fixed << setprecision(2)
			<< getAlternatePrice();

		cout << " Alternate Price History: (";
		alternatePriceHistory.output();
		cout << endl;

		cout << "Average Exchange Rate: " << getAverageExchangeRate() << endl;

		if (taxable)
			cout << "Taxable";
		else
			cout << "Non-taxable";
		
		
	}

	double Product::getAverageExchangeRate() const
	{
			double sum = 0.0;
			int count = 0;
			for (int i = 0; i < priceHistory.size(); i++)
			{
				sum += priceHistory.get(i) / alternatePriceHistory.get(i);
		        count++;
	
			}
			return sum / count;
		
	}

	// Precondition: taxRate must be non-negative and represented
	// as a decimal (e.g., 0.05 for 5%).
	// Postcondition: Returns amount of tax based on price of
	// product and given taxRate.
	double Product::computeTax(double taxRate) const
	{
		if (taxable)
			return price * taxRate;
		else
			return 0.0;
	}

	// Mutators

	// Precondition: newPrice must be a non-negative number.
	void Product::set(const string& newId,
					  double newPrice,
					  bool newTaxable)
	{
		setPrice(newPrice);  // Store price and check whether valid
		id = newId;
		taxable = newTaxable;

	}

	// Precondition: newPrice must be a non-negative number.
	void Product::setPrice(double newPrice)
	{
		price = newPrice;

		if (newPrice < 0.0)
			cerr << "Product price should be non-negative." << endl;

		priceHistory.add(price);
		alternatePriceHistory.add(price / exchangeRate);
	}


	void Product::setExchangeRate(double newExchangeRate)
		
	{
		exchangeRate = newExchangeRate;

	}
  
} 