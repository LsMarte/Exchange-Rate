/*
 * Name: YOUR NAME
 * History Class Definition
 * Course: CSI 218 (Spring 2025)
 * Lecture: Tools for Data Structures
 * Date: January 27, 2025
 * Description: History template class definition declaring
 *				data members and member functions for type "T".
 */

#ifndef HISTORY_H
#define HISTORY_H

// History template class definition with data members and
// prototypes for member functions.

template<class T>  // TEMPLATE PREFIX
class History
{
public:
	
	// Constructors
	History();  // default constructor (no parameters)

	// Accessors
	T get(int i) const;  // USE TEMPLATE PARAMETER, T

	void output() const;

	double size() const; // change the return type to int

	// Mutators
	void add(const T& val);


	// Reset
	void clear();

private:

	static const int MAX_HISTORY = 5; //Maximun number of history entries
	T stored[MAX_HISTORY]; //array to store history
	
};

#endif