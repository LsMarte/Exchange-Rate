/*
 * Name: Luis Marte
 * Exercise 1: Exchange Rate
 * Course: CSI 218 (Spring 2025)
 * Lecture: Tools for Data Structures
 * Date: January 27, 2025
 * Description: Using class to represent products (price
 *				history handled by template class).
 */

#include <iostream>
#include "product.h"


using namespace std;
using namespace Store;

void increasePrice(Product incrProds[], int numProds, double amt);

int main()
{
	const int NUM_PRODUCTS = 5;
	string ids[NUM_PRODUCTS] = {  // Ids for new products
		"12-567-01",
		"12-567-02",
		"12-567-03",
		"12-567-04",
		"12-567-05"
	};
	// Declare array of objects (class type Product).
	Product products[NUM_PRODUCTS];

	// Set exchange rates
	products[0].setExchangeRate(1.5);  // 1 USD = 1.5 alternate currency
	products[1].setExchangeRate(2.0);
	products[2].setExchangeRate(0.8);
	products[3].setExchangeRate(1.2);
	products[4].setExchangeRate(1.0);


	// Add a set of products (all same price).
	for (int i = 0; i < NUM_PRODUCTS; i++)
	{
		products[i].set(ids[i], 0.99, false);
	}

	// Increase prices by $1.
	increasePrice(products, NUM_PRODUCTS, 1.00);

	// Set some more prices to demonstrate history
	products[0].setPrice(2.50);
	products[0].setPrice(3.00);

	// Output info for each.
	cout << " Candy bars: " << endl << endl;

	for (int i = 0; i < NUM_PRODUCTS; i++)
	{
		products[i].output();
		cout << "Average Exchange Rate: " <<
			products[i].getAverageExchangeRate() << endl;
		cout << endl << endl;
	}

	return 0;
}

void increasePrice(Product incrProds[], int numProds, double amt)
{
	for (int i = 0; i < numProds; i++)
	{
		// Increase price by given amount.
		incrProds[i].setPrice(incrProds[i].getPrice() + amt);
	}
}
